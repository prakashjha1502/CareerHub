package com.hexaware.exception;

public class DeadlineExceedException extends Exception{
public DeadlineExceedException(String message) {
	super(message);
}
}
