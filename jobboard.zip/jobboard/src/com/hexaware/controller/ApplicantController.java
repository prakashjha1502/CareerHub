package com.hexaware.controller;

public class ApplicantController {

}
