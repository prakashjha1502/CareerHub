package com.hexaware.dao;

public class ApplicantService {

}
