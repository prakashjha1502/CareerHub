import java.io.FileNotFoundException;
import java.io.IOException;
import java.sql.SQLException;

import com.hexaware.controller.JobListingController;




public class Main {

	public static void main(String[] args)  {
		
		 
		JobListingController  job=new  JobListingController();
   
   job.start();
	}

}
